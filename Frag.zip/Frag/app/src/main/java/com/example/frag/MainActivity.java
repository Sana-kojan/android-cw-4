package com.example.frag;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewPager vp = findViewById(R.id.vpp);
        TabLayout t1= findViewById(R.id.tt);

        fragAdapter ad = new fragAdapter(getSupportFragmentManager());
        vp.setAdapter(ad);
        t1.setupWithViewPager(vp);
        t1.getTabAt(0).setIcon(R.drawable.ic_baseline_home_24);
        t1.getTabAt(1).setIcon(R.drawable.ic_baseline_format_list_bulleted_24);
        t1.getTabAt(2).setIcon(R.drawable.ic_baseline_flare_24);




    }
}